# Pacote de integrações externas do Codex CLI
