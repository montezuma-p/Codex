# Pacote principal do Codex CLI
